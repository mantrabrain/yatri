<div class="post-format-outer">
						<span class="post-format">
							<span class="fab<?php echo esc_attr(yatri_get_fa_icon_for_post_format()); ?>"></span>
						</span>
</div>