<div class="copyright">
	<?php echo wp_kses_post( html_entity_decode( yatri_get_option( 'footer_text' ) ) ); ?> <?php esc_html_e( 'Yatri Theme by', 'yatri' ); ?> <a href="<?php echo esc_url( '//mantrabrain.com' ); ?>" target="_blank"> <?php esc_html_e( 'Mantrabrain', 'yatri' ); ?> </a>
</div><!-- .site-info -->