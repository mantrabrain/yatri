<div class="yatri-post-content-wrap yatri-content-item" >

    <?php
    the_content();
    ?>

</div>
