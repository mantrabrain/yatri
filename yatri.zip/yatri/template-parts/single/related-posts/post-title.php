<header class="post-title">
    <h2 class="entry-title">
        <a href="<?php echo esc_url(get_the_permalink()) ?>">
            <?php the_title(); ?>
        </a></h2>
</header>