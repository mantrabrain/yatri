<?php if (has_post_thumbnail()): ?>
    <div class="post-thumbnail">
        <?php the_post_thumbnail('yatri-1200-850'); ?>
    </div>
<?php endif; ?>